import '../entities/day_schedule.dart';
import '../entities/schedule_item.dart';
import '../enums/schedule_item_type.dart';

class PlanQualityAudit {
  const PlanQualityAudit({
    required this.totalWaitMinutes,
    required this.totalFreeMinutes,
    required this.largestFreeBlockMinutes,
    required this.smallFreeBlockCount,
    required this.minimumGapMinutes,
    required this.overlapCount,
    required this.robustnessLevel,
    required this.robustnessMessage,
  });

  final int totalWaitMinutes;
  final int totalFreeMinutes;
  final int largestFreeBlockMinutes;
  final int smallFreeBlockCount;
  final int minimumGapMinutes;
  final int overlapCount;
  final String robustnessLevel;
  final String robustnessMessage;
}

class PlanQualityAuditService {
  const PlanQualityAuditService();

  PlanQualityAudit evaluate(DaySchedule schedule) {
    final items = [...schedule.items]..sort((a, b) => _start(a).compareTo(_start(b)));
    var wait = 0;
    var free = 0;
    var largestFree = 0;
    var smallFree = 0;
    var overlaps = 0;

    for (var i = 0; i < items.length; i++) {
      final item = items[i];
      wait += item.effectiveQueueMinutes ?? 0;
      if (item.type == ScheduleItemType.breakTime) {
        final rawDuration = _end(item) - _start(item);
        final duration = rawDuration < 0 ? 0 : (rawDuration > 24 * 60 ? 24 * 60 : rawDuration);
        free += duration;
        if (duration > largestFree) largestFree = duration;
        if (duration < 30) smallFree++;
      }
      if (i > 0 && _start(item) < _end(items[i - 1])) overlaps++;
    }

    // Entry/exit boundaries are not ordinary inter-plan slack.
    final active = items
        .where((item) =>
            item.type != ScheduleItemType.breakTime &&
            item.type != ScheduleItemType.entry &&
            item.type != ScheduleItemType.exit)
        .toList(growable: false);
    int? minimumGap;
    for (var i = 1; i < active.length; i++) {
      final gap = _start(active[i]) - _end(active[i - 1]);
      if (gap < 0) continue;
      minimumGap = minimumGap == null ? gap : (gap < minimumGap ? gap : minimumGap);
    }
    final minGap = minimumGap ?? 0;
    final (level, message) = switch ((overlaps, minGap, largestFree)) {
      (> 0, _, _) => ('要確認', '予定の重なりがあります。固定予定と移動条件を確認してください。'),
      (0, < 10, _) => ('余裕少なめ', '主要予定間の最小余裕が10分未満です。小さな遅延の影響を受けやすいプランです。'),
      (0, < 20, _) => ('標準', '主要予定間に一定の余裕がありますが、10〜20分程度の遅延には注意が必要です。'),
      (0, _, >= 60) => ('余裕あり', '主要予定間の余裕に加えて、60分以上のまとまった自由時間があります。'),
      _ => ('標準', '大きな時間矛盾はありません。実際の待ち時間変動には当日再最適化で対応します。'),
    };

    return PlanQualityAudit(
      totalWaitMinutes: wait,
      totalFreeMinutes: free,
      largestFreeBlockMinutes: largestFree,
      smallFreeBlockCount: smallFree,
      minimumGapMinutes: minGap,
      overlapCount: overlaps,
      robustnessLevel: level,
      robustnessMessage: message,
    );
  }

  int _start(ScheduleItem item) => item.startHour * 60 + item.startMinute;
  int _end(ScheduleItem item) => item.endHour * 60 + item.endMinute;
}
